﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'sk', {
	btn_about: 'O KPPP (Kontrola pravopisu počas písania)',
	btn_dictionaries: 'Slovníky',
	btn_disable: 'Zakázať  KPPP (Kontrola pravopisu počas písania)',
	btn_enable: 'Povoliť KPPP (Kontrola pravopisu počas písania)',
	btn_langs:'Jazyky',
	btn_options: 'Možnosti',
	text_title:  'Kontrola pravopisu počas písania'
});
