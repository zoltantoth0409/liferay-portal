﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'hu', {
	btn_about: 'SCAYT névjegy',
	btn_dictionaries: 'Szótár',
	btn_disable: 'SCAYT letiltása',
	btn_enable: 'SCAYT engedélyezése',
	btn_langs:'Nyelvek',
	btn_options: 'Beállítások',
	text_title:  'Helyesírás ellenőrzés gépelés közben'
});
