﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'vi', {
	btn_about: 'Thông tin về SCAYT',
	btn_dictionaries: 'Từ điển',
	btn_disable: 'Tắt SCAYT',
	btn_enable: 'Bật SCAYT',
	btn_langs:'Ngôn ngữ',
	btn_options: 'Tùy chọn',
	text_title:  'Kiểm tra chính tả ngay khi gõ chữ (SCAYT)'
});
