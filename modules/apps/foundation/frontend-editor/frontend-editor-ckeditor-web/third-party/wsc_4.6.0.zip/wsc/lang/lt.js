﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'lt', {
	btnIgnore: 'Ignoruoti',
	btnIgnoreAll: 'Ignoruoti visus',
	btnReplace: 'Pakeisti',
	btnReplaceAll: 'Pakeisti visus',
	btnUndo: 'Atšaukti',
	changeTo: 'Pakeisti į',
	errorLoading: 'Klaida įkraunant servisą: %s.',
	ieSpellDownload: 'Rašybos tikrinimas neinstaliuotas. Ar Jūs norite jį dabar atsisiųsti?',
	manyChanges: 'Rašybos tikrinimas baigtas: Pakeista %1 žodžių',
	noChanges: 'Rašybos tikrinimas baigtas: Nėra pakeistų žodžių',
	noMispell: 'Rašybos tikrinimas baigtas: Nerasta rašybos klaidų',
	noSuggestions: '- Nėra pasiūlymų -',
	notAvailable: 'Atleiskite, šiuo metu servisas neprieinamas.',
	notInDic: 'Žodyne nerastas',
	oneChange: 'Rašybos tikrinimas baigtas: Vienas žodis pakeistas',
	progress: 'Vyksta rašybos tikrinimas...',
	title: 'Tikrinti klaidas',
	toolbar: 'Rašybos tikrinimas'
});
