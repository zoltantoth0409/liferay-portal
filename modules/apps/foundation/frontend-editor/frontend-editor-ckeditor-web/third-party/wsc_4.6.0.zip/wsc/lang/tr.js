﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'tr', {
	btnIgnore: 'Yoksay',
	btnIgnoreAll: 'Tümünü Yoksay',
	btnReplace: 'Değiştir',
	btnReplaceAll: 'Tümünü Değiştir',
	btnUndo: 'Geri Al',
	changeTo: 'Şuna değiştir:',
	errorLoading: 'Uygulamada yüklerken hata oluştu: %s.',
	ieSpellDownload: 'Yazım denetimi yüklenmemiş. Şimdi yüklemek ister misiniz?',
	manyChanges: 'Yazım denetimi tamamlandı: %1 kelime değiştirildi',
	noChanges: 'Yazım denetimi tamamlandı: Hiçbir kelime değiştirilmedi',
	noMispell: 'Yazım denetimi tamamlandı: Yanlış yazıma rastlanmadı',
	noSuggestions: '- Öneri Yok -',
	notAvailable: 'Üzügünüz, bu servis şuanda hizmet dışıdır.',
	notInDic: 'Sözlükte Yok',
	oneChange: 'Yazım denetimi tamamlandı: Bir kelime değiştirildi',
	progress: 'Yazım denetimi işlemde...',
	title: 'Yazımı Denetle',
	toolbar: 'Yazım Denetimi'
});
