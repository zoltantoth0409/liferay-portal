﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'cs', {
	btnIgnore: 'Přeskočit',
	btnIgnoreAll: 'Přeskakovat vše',
	btnReplace: 'Zaměnit',
	btnReplaceAll: 'Zaměňovat vše',
	btnUndo: 'Zpět',
	changeTo: 'Změnit na',
	errorLoading: 'Chyba nahrávání služby aplikace z: %s.',
	ieSpellDownload: 'Kontrola pravopisu není nainstalována. Chcete ji nyní stáhnout?',
	manyChanges: 'Kontrola pravopisu dokončena: %1 slov změněno',
	noChanges: 'Kontrola pravopisu dokončena: Beze změn',
	noMispell: 'Kontrola pravopisu dokončena: Žádné pravopisné chyby nenalezeny',
	noSuggestions: '- žádné návrhy -',
	notAvailable: 'Omlouváme se, ale služba nyní není dostupná.',
	notInDic: 'Není ve slovníku',
	oneChange: 'Kontrola pravopisu dokončena: Jedno slovo změněno',
	progress: 'Probíhá kontrola pravopisu...',
	title: 'Kontrola pravopisu',
	toolbar: 'Zkontrolovat pravopis'
});
