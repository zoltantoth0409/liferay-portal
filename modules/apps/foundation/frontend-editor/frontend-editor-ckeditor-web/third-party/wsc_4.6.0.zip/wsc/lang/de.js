﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'de', {
	btnIgnore: 'Ignorieren',
	btnIgnoreAll: 'Alle Ignorieren',
	btnReplace: 'Ersetzen',
	btnReplaceAll: 'Alle Ersetzen',
	btnUndo: 'Rückgängig',
	changeTo: 'Ändern in',
	errorLoading: 'Fehler beim laden des Dienstanbieters: %s.',
	ieSpellDownload: 'Rechtschreibprüfung nicht installiert. Möchten Sie sie jetzt herunterladen?',
	manyChanges: 'Rechtschreibprüfung abgeschlossen - %1 Wörter geändert',
	noChanges: 'Rechtschreibprüfung abgeschlossen - keine Worte geändert',
	noMispell: 'Rechtschreibprüfung abgeschlossen - keine Fehler gefunden',
	noSuggestions: ' - keine Vorschläge - ',
	notAvailable: 'Entschuldigung, aber dieser Dienst steht im Moment nicht zur Verfügung.',
	notInDic: 'Nicht im Wörterbuch',
	oneChange: 'Rechtschreibprüfung abgeschlossen - ein Wort geändert',
	progress: 'Rechtschreibprüfung läuft...',
	title: 'Rechtschreibprüfung',
	toolbar: 'Rechtschreibprüfung'
});
