﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'nb', {
	btnIgnore: 'Ignorer',
	btnIgnoreAll: 'Ignorer alle',
	btnReplace: 'Erstatt',
	btnReplaceAll: 'Erstatt alle',
	btnUndo: 'Angre',
	changeTo: 'Endre til',
	errorLoading: 'Feil under lasting av applikasjonstjenestetjener: %s.',
	ieSpellDownload: 'Stavekontroll er ikke installert. Vil du laste den ned nå?',
	manyChanges: 'Stavekontroll fullført: %1 ord endret',
	noChanges: 'Stavekontroll fullført: ingen ord endret',
	noMispell: 'Stavekontroll fullført: ingen feilstavinger funnet',
	noSuggestions: '- Ingen forslag -',
	notAvailable: 'Beklager, tjenesten er utilgjenglig nå.',
	notInDic: 'Ikke i ordboken',
	oneChange: 'Stavekontroll fullført: Ett ord endret',
	progress: 'Stavekontroll pågår...',
	title: 'Stavekontroll',
	toolbar: 'Stavekontroll'
});
