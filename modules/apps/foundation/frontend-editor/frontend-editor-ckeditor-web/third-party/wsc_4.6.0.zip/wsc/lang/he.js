﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'he', {
	btnIgnore: 'התעלמות',
	btnIgnoreAll: 'התעלמות מהכל',
	btnReplace: 'החלפה',
	btnReplaceAll: 'החלפת הכל',
	btnUndo: 'החזרה',
	changeTo: 'שינוי ל',
	errorLoading: 'שגיאה בהעלאת השירות: %s.',
	ieSpellDownload: 'בודק האיות לא מותקן, האם להורידו?',
	manyChanges: 'בדיקות איות הסתיימה: %1 מילים שונו',
	noChanges: 'בדיקות איות הסתיימה: לא שונתה אף מילה',
	noMispell: 'בדיקות איות הסתיימה: לא נמצאו שגיאות כתיב',
	noSuggestions: '- אין הצעות -',
	notAvailable: 'לא נמצא שירות זמין.',
	notInDic: 'לא נמצא במילון',
	oneChange: 'בדיקות איות הסתיימה: שונתה מילה אחת',
	progress: 'בודק האיות בתהליך בדיקה....',
	title: 'בדיקת איות',
	toolbar: 'בדיקת איות'
});
