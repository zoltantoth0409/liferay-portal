﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'pt', {
	btnIgnore: 'Ignorar',
	btnIgnoreAll: 'Ignorar Tudo',
	btnReplace: 'Substituir',
	btnReplaceAll: 'Substituir Tudo',
	btnUndo: 'Anular',
	changeTo: 'Mudar para',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: ' Verificação ortográfica não instalada. Quer descarregar agora?',
	manyChanges: 'Verificação ortográfica completa: %1 palavras alteradas',
	noChanges: 'Verificação ortográfica completa: não houve alteração de palavras',
	noMispell: 'Verificação ortográfica completa: não foram encontrados erros',
	noSuggestions: '- Sem sugestões -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'Não está num directório',
	oneChange: 'Verificação ortográfica completa: uma palavra alterada',
	progress: 'Verificação ortográfica em progresso…',
	title: 'Spell Checker',
	toolbar: 'Verificação Ortográfica'
});
