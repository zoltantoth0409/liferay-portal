﻿/*
 Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","bg",{title:"Настройки на контейнера",toolbar:"Нов контейнер",text:"Текст за контейнера",edit:"Промяна на контейнер",textMissing:"Контейнера трябва да съдържа текст."});